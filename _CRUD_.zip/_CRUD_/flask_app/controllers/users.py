from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.config.mysqlconnection import connectToMySQL

from flask_app.models.user import User 

@app.route("/")
def index():
    return render_template("index.html", users = User.get_all_users())

@app.route("/show/<int:user_id>")
def show(user_id):
    data = {
        'id' : user_id
    }
    return render_template("show.html", user = User.get_user_id(data))

@app.route("/edit/<int:user_id>")
def edit_user(user_id):
    data = {
        "id": user_id
    }
    return render_template('edit.html', edit_user= User.get_user_id(data))

@app.route("/edit/update/<int:user_id>", methods=["POST"])
def edit_update(user_id):
    data = {
        'fn': request.form['fname'],
        'em': request.form['email'],
        'id': user_id
    }
    User.edit_user(data)
    return redirect("/")