from flask import Flask, flash, redirect, render_template

app = Flask(__name__)
app.secret_key = 'modularity :)!!'