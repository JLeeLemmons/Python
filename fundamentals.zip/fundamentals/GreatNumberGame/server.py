from flask import Flask, render_template, request, redirect, session
import random


app = Flask(__name__)
app.secret_key = "secret key"

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/number', methods=["post"])
def number(number):
    random_num = random.randint(1,100)
    session['number'] = random_num
    number_id = number 
    if session['number'] > {number_id}:
        return "Too Low!"
    elif session['number'] < {number_id}:
        return "Too High!"
    else:
     return "{number_id} was the number!"
    

@app.route('/try_again', methods=["post"])
def TryAgain():
    clear()
    return redirect('/')


    
if __name__=="__main__":
    app.run(debug = True)



